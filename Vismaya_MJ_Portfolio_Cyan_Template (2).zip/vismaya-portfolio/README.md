# Vismaya M J – Portfolio

## Publish with GitHub Pages
1. Create a GitHub repository named `vismaya-portfolio`.
2. Upload `index.html`, `Vismaya_MJ_Observability_Resume.pdf`, and this README to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. GitHub will provide your public website URL.

The hero **Contact Me** button opens the phone dialler using the `tel:` link. The resume button opens the PDF stored alongside `index.html`.

Before publishing, check that all details are accurate and share only approved, non-confidential work information.
